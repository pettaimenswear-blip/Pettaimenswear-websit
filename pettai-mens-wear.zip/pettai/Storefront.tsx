import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import logo from './logo.png'
import {
  CATEGORIES,
  STOCK_LABEL,
  STORE,
  fetchProducts,
  inr,
  isConfigured,
  type Product,
} from './lib'

type Filter = 'All' | 'Offers' | (typeof CATEGORIES)[number]
const FILTERS: Filter[] = ['All', 'Offers', ...CATEGORIES]

const percentOff = (p: Product) =>
  p.offer_price ? Math.round((1 - p.offer_price / p.price) * 100) : 0

export default function Storefront() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<Filter>('All')
  const [selected, setSelected] = useState<Product | null>(null)

  useEffect(() => {
    if (!isConfigured) {
      setLoading(false)
      return
    }
    fetchProducts()
      .then(setProducts)
      .catch(() => setError('We could not load the products. Please refresh the page.'))
      .finally(() => setLoading(false))
  }, [])

  const offers = useMemo(() => products.filter((p) => p.offer_price), [products])

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return products.filter((p) => {
      if (filter === 'Offers' && !p.offer_price) return false
      if (filter !== 'All' && filter !== 'Offers' && p.category !== filter) return false
      if (!q) return true
      return [p.name, p.category, p.description ?? '', ...p.colors].join(' ').toLowerCase().includes(q)
    })
  }, [products, query, filter])

  const showOfferStrip = filter === 'All' && !query.trim() && offers.length > 0

  return (
    <>
      <header className="hero">
        <img className="hero-logo" src={logo} alt="PETTAI MEN'S WEAR logo" width={1659} height={948} />
        <h1 className="brand">{STORE.name}</h1>
        <p className="tagline">Shirts, jeans and pants for men, from Mangalam Pettai</p>
        <div className="hero-actions">
          <a className="btn btn-gold" href={`https://ig.me/m/${STORE.instagram}`} target="_blank" rel="noopener noreferrer">
            Order on Instagram
          </a>
          <a className="btn btn-line" href={STORE.phoneHref}>
            Call {STORE.phoneDisplay}
          </a>
        </div>
      </header>

      <main className="shop" id="shop">
        <div className="toolbar">
          <input
            className="search"
            type="search"
            placeholder="Search shirts, jeans, cargo, colors…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="Search products"
          />
          <div className="chips" role="tablist" aria-label="Product categories">
            {FILTERS.map((f) => (
              <button
                key={f}
                role="tab"
                aria-selected={filter === f}
                className={`chip ${filter === f ? 'chip-on' : ''}`}
                onClick={() => setFilter(f)}
              >
                {f === 'Offers' ? 'Special offers' : f}
              </button>
            ))}
          </div>
        </div>

        {!isConfigured && (
          <p className="notice">The shop is not connected to its database yet. Follow Step 5 of the setup guide.</p>
        )}
        {error && <p className="notice notice-error">{error}</p>}
        {loading && <p className="notice">Loading products…</p>}

        {showOfferStrip && (
          <section className="offers">
            <h2>Special offers</h2>
            <div className="offer-row">
              {offers.map((p) => (
                <Card key={p.id} p={p} onOpen={setSelected} />
              ))}
            </div>
          </section>
        )}

        {!loading && !error && isConfigured && (
          <section>
            <h2>{filter === 'All' ? 'All products' : filter === 'Offers' ? 'Special offers' : filter}</h2>
            {visible.length === 0 ? (
              <p className="notice">
                {products.length === 0
                  ? 'New styles are coming soon. Message us on Instagram to ask what is in the shop.'
                  : 'Nothing matches your search. Try another word or category.'}
              </p>
            ) : (
              <div className="grid">
                {visible.map((p) => (
                  <Card key={p.id} p={p} onOpen={setSelected} />
                ))}
              </div>
            )}
          </section>
        )}
      </main>

      <footer className="footer">
        <img className="footer-logo" src={logo} alt="" width={240} height={137} loading="lazy" />
        <h2>{STORE.name}</h2>
        <address>
          {STORE.address}
          <br />
          <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(STORE.name + ' ' + STORE.address)}`} target="_blank" rel="noopener noreferrer">
            Open in Maps
          </a>
        </address>
        <p>
          <a href={STORE.phoneHref}>{STORE.phoneDisplay}</a>
        </p>
        <p>
          <a href={`https://instagram.com/${STORE.instagram}`} target="_blank" rel="noopener noreferrer">
            Instagram @{STORE.instagram}
          </a>
        </p>
        <p className="fine">
          © {new Date().getFullYear()} {STORE.name}. <Link to="/admin">Staff login</Link>
        </p>
      </footer>

      {selected && <Details p={selected} onClose={() => setSelected(null)} />}
    </>
  )
}

function Card({ p, onOpen }: { p: Product; onOpen: (p: Product) => void }) {
  const sold = p.stock_status === 'out_of_stock'
  return (
    <button className={`card ${sold ? 'card-sold' : ''}`} onClick={() => onOpen(p)}>
      <span className="card-img">
        {p.image_url ? <img src={p.image_url} alt={p.name} loading="lazy" /> : <span className="no-img">No photo</span>}
        {p.offer_price && <span className="badge">{percentOff(p)}% off</span>}
      </span>
      <span className="card-body">
        <span className="card-cat">{p.category}</span>
        <span className="card-name">{p.name}</span>
        <span className="price">
          <strong>{inr(p.offer_price ?? p.price)}</strong>
          {p.offer_price && <s>{inr(p.price)}</s>}
        </span>
        <span className={`stock stock-${p.stock_status}`}>{STOCK_LABEL[p.stock_status]}</span>
      </span>
    </button>
  )
}

function Details({ p, onClose }: { p: Product; onClose: () => void }) {
  const [size, setSize] = useState('')
  const [color, setColor] = useState('')
  const [copied, setCopied] = useState(false)
  const sold = p.stock_status === 'out_of_stock'

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [onClose])

  const message =
    `Hello ${STORE.name}! I would like to order:\n` +
    `${p.name} (${p.category})\n` +
    `Size: ${size || 'to confirm'}\n` +
    `Color: ${color || 'to confirm'}\n` +
    `Price: ${inr(p.offer_price ?? p.price)}`

  // The copy happens inside the tap itself, so iPhone allows it.
  const order = () => {
    navigator.clipboard?.writeText(message).then(() => setCopied(true)).catch(() => undefined)
  }

  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label={p.name} onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={onClose} aria-label="Close">
          ✕
        </button>
        {p.image_url && <img className="sheet-img" src={p.image_url} alt={p.name} />}
        <div className="sheet-body">
          <p className="card-cat">{p.category}</p>
          <h2>{p.name}</h2>
          <p className="price big">
            <strong>{inr(p.offer_price ?? p.price)}</strong>
            {p.offer_price && <s>{inr(p.price)}</s>}
            {p.offer_price && <span className="badge badge-inline">{percentOff(p)}% off</span>}
          </p>
          <p className={`stock stock-${p.stock_status}`}>{STOCK_LABEL[p.stock_status]}</p>
          {p.description && <p className="desc">{p.description}</p>}

          {p.sizes.length > 0 && (
            <fieldset>
              <legend>Size</legend>
              <div className="opts">
                {p.sizes.map((s) => (
                  <button key={s} className={`opt ${size === s ? 'opt-on' : ''}`} onClick={() => setSize(s)}>
                    {s}
                  </button>
                ))}
              </div>
            </fieldset>
          )}
          {p.colors.length > 0 && (
            <fieldset>
              <legend>Color</legend>
              <div className="opts">
                {p.colors.map((c) => (
                  <button key={c} className={`opt ${color === c ? 'opt-on' : ''}`} onClick={() => setColor(c)}>
                    {c}
                  </button>
                ))}
              </div>
            </fieldset>
          )}

          {sold ? (
            <p className="notice">This style is sold out. Message us to ask when it will be back.</p>
          ) : (
            <>
              <a
                className="btn btn-gold btn-full"
                href={`https://ig.me/m/${STORE.instagram}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={order}
              >
                Order on Instagram
              </a>
              <p className="hint">
                {copied
                  ? 'Your order details are copied. Paste them into the chat and send.'
                  : 'Tapping the button copies your order details. Paste them into the Instagram chat.'}
              </p>
            </>
          )}
          <a className="btn btn-line btn-full" href={STORE.phoneHref}>
            Call {STORE.phoneDisplay}
          </a>
        </div>
      </div>
    </div>
  )
}
