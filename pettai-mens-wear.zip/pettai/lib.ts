import { createClient } from '@supabase/supabase-js'

/* ---------- Store details (edit here to change them everywhere) ---------- */
export const STORE = {
  name: "PETTAI MEN'S WEAR",
  instagram: 'pettaimenswear',
  phoneDisplay: '+91 63799 70507',
  phoneHref: 'tel:+916379970507',
  address:
    '2 C Main Road, Mangalam Pettai, Virudhachalam TK, Cuddalore DT, Tamil Nadu - 606104',
}

export const CATEGORIES = [
  'Shirts',
  'T-Shirts',
  'Jeans',
  'Formal Pants',
  'Baggy Pants',
  'Cargo Pants',
  'Gurkha Pants',
  'Cotton Pants',
] as const
export type Category = (typeof CATEGORIES)[number]

export type StockStatus = 'in_stock' | 'low_stock' | 'out_of_stock'
export const STOCK_LABEL: Record<StockStatus, string> = {
  in_stock: 'In stock',
  low_stock: 'Only a few left',
  out_of_stock: 'Sold out',
}

export const TOP_SIZES = ['S', 'M', 'L', 'XL', 'XXL']
export const BOTTOM_SIZES = ['28', '30', '32', '34', '36', '38', '40', '42']
export const isTopCategory = (c: string) => c === 'Shirts' || c === 'T-Shirts'

export interface Product {
  id: string
  name: string
  description: string | null
  category: Category
  price: number
  offer_price: number | null
  sizes: string[]
  colors: string[]
  stock_status: StockStatus
  image_url: string | null
  image_path: string | null
  created_at: string
}
export type ProductInput = Omit<Product, 'id' | 'created_at'>

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})
export const inr = (n: number) => inrFormat.format(n)

/* ---------- Supabase connection (public URL + public anon key only) ---------- */
const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined
export const isConfigured = Boolean(url && anonKey)
export const supabase = createClient(url ?? 'http://localhost', anonKey ?? 'missing-key')

const BUCKET = 'product-images'

/* ---------- Data functions ---------- */
export async function fetchProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) throw new Error(error.message)
  return (data ?? []) as Product[]
}

export async function saveProduct(input: ProductInput, id?: string): Promise<void> {
  const query = id
    ? supabase.from('products').update(input).eq('id', id)
    : supabase.from('products').insert(input)
  const { error } = await query
  if (error) throw new Error(error.message)
}

export async function removeImage(path: string | null): Promise<void> {
  if (!path) return
  await supabase.storage.from(BUCKET).remove([path])
}

export async function deleteProduct(p: Product): Promise<void> {
  const { error } = await supabase.from('products').delete().eq('id', p.id)
  if (error) throw new Error(error.message)
  await removeImage(p.image_path)
}

/** Shrinks the photo (iPhone photos are huge) and uploads it. Returns its public link. */
export async function uploadImage(file: File): Promise<{ url: string; path: string }> {
  const bitmap = await createImageBitmap(file)
  const scale = Math.min(1, 1200 / Math.max(bitmap.width, bitmap.height))
  const canvas = document.createElement('canvas')
  canvas.width = Math.round(bitmap.width * scale)
  canvas.height = Math.round(bitmap.height * scale)
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Could not prepare the image.')
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
  const blob: Blob = await new Promise((resolve, reject) =>
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('Image conversion failed.'))), 'image/jpeg', 0.85),
  )
  const path = `${crypto.randomUUID()}.jpg`
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, blob, { contentType: 'image/jpeg', cacheControl: '31536000' })
  if (error) throw new Error(error.message)
  return { url: supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl, path }
}
