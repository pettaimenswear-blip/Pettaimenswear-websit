-- PETTAI MEN'S WEAR: database, security rules (RLS) and image storage.
-- Paste this whole file into Supabase > SQL Editor > New query > Run.
-- It is safe to run only once on a fresh project.

-- 1) Products table -----------------------------------------------------------
create table public.products (
  id           uuid primary key default gen_random_uuid(),
  name         text not null check (char_length(name) between 2 and 120),
  description  text check (char_length(description) <= 1000),
  category     text not null check (category in (
                 'Shirts','T-Shirts','Jeans','Formal Pants',
                 'Baggy Pants','Cargo Pants','Gurkha Pants','Cotton Pants')),
  price        numeric(10,2) not null check (price > 0),
  offer_price  numeric(10,2) check (offer_price is null or (offer_price > 0 and offer_price < price)),
  sizes        text[] not null default '{}',
  colors       text[] not null default '{}',
  stock_status text not null default 'in_stock'
               check (stock_status in ('in_stock','low_stock','out_of_stock')),
  image_url    text,
  image_path   text,
  created_at   timestamptz not null default now()
);
create index products_category_idx on public.products (category);

-- 2) Admin list: only people listed here can change products -------------------
create table public.admins (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;

-- 3) Row Level Security --------------------------------------------------------
alter table public.products enable row level security;
alter table public.admins   enable row level security;

-- Everyone (customers) can look at products
create policy "Anyone can view products" on public.products
  for select to anon, authenticated using (true);

-- Only admins can add, change or delete products
create policy "Admins can add products" on public.products
  for insert to authenticated with check (public.is_admin());
create policy "Admins can edit products" on public.products
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admins can delete products" on public.products
  for delete to authenticated using (public.is_admin());

-- A signed-in user may only see their own row in admins (nobody can edit it from the website)
create policy "Users can see their own admin row" on public.admins
  for select to authenticated using (user_id = auth.uid());

-- 4) Image storage ------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880,
        array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "Anyone can view product images" on storage.objects
  for select to anon, authenticated using (bucket_id = 'product-images');
create policy "Admins can upload product images" on storage.objects
  for insert to authenticated with check (bucket_id = 'product-images' and public.is_admin());
create policy "Admins can replace product images" on storage.objects
  for update to authenticated
  using (bucket_id = 'product-images' and public.is_admin())
  with check (bucket_id = 'product-images' and public.is_admin());
create policy "Admins can delete product images" on storage.objects
  for delete to authenticated using (bucket_id = 'product-images' and public.is_admin());
