# PETTAI MEN'S WEAR: website

React + TypeScript + Supabase, deployed on Vercel through GitHub.
Everything is in one flat folder so you can upload it from an iPhone without a computer.

## Files
| File | What it does |
|---|---|
| `logo.png` | Your original logo, unchanged |
| `Storefront.tsx` | The customer website: logo, search, categories, offers, product sheet, Instagram order |
| `Admin.tsx` | Staff login at `/admin`, add / edit / delete products, photo upload |
| `lib.ts` | Store details (phone, address, Instagram), Supabase connection, database functions |
| `styles.css` | Black, white and gold design, built for phones first |
| `schema.sql` | Database tables, Row Level Security rules, image storage rules |
| `main.tsx`, `index.html`, `vite.config.ts`, `tsconfig.json`, `package.json`, `vite-env.d.ts` | Project setup |
| `vercel.json` | Makes `/admin` open correctly and adds security headers |
| `env-example.txt` | The two settings you give Vercel |

## Setup (do the steps in order)

### Step 1. Create the Supabase project
1. Go to supabase.com, sign up, tap **New project**.
2. Name it `pettai`, choose a strong database password (save it in your notes), pick the region closest to India (Mumbai / Singapore), tap **Create**. Wait about 2 minutes.

### Step 2. Create the database
1. Open `schema.sql` (from this folder), select all text, copy it.
2. In Supabase: **SQL Editor** > **New query** > paste > **Run**.
3. You should see "Success. No rows returned". Check **Table Editor** shows `products` and `admins`.

### Step 3. Create your admin account
1. **Authentication** > **Sign In / Providers**: turn **off** "Allow new users to sign up".
2. **Authentication** > **Users** > **Add user** > **Create new user**. Enter your email and a strong password. Tick **Auto Confirm User**.
3. **SQL Editor** > new query, paste this with YOUR email, then **Run**:
   `insert into public.admins (user_id) select id from auth.users where email = 'you@example.com';`
   It should say "Success. 1 row affected".

### Step 4. Put the project on GitHub
1. Sign up at github.com. Tap **+** > **New repository**. Name: `pettai-mens-wear`. Choose **Private**. Tap **Create repository**.
2. Tap **uploading an existing file**. Tap **Choose your files** > **Browse** and select **all** files from this folder, including `logo.png`. Wait for the uploads to finish.
3. Tap **Commit changes**. You should see all files listed in the repository.

### Step 5. Deploy on Vercel and connect the database
1. In Supabase: **Project Settings** > **API**. Copy the **Project URL** and the **anon / publishable** key. Never copy the `service_role` or secret key.
2. Sign up at vercel.com with GitHub. Tap **Add New** > **Project** > import `pettai-mens-wear`.
3. Before deploying, open **Environment Variables** and add:
   - `VITE_SUPABASE_URL` = your Project URL
   - `VITE_SUPABASE_ANON_KEY` = your anon / publishable key
4. Tap **Deploy**. When it finishes, open the link Vercel gives you.

### Step 6. Tell Supabase your website address
**Authentication** > **URL Configuration**: set **Site URL** to your Vercel link (for example `https://pettai-mens-wear.vercel.app`).

### Step 7. Test everything (all must pass)
1. **Home**: your logo is centred at the top, PETTAI MEN'S WEAR is below it.
2. **Admin login**: open `your-link/admin`. A wrong password shows an error. Your correct login opens the product list.
3. **Add product**: add one product with a photo, price, offer price, sizes, colors. It appears in the list.
4. **Image upload**: the photo shows in the list. In Supabase > Storage > `product-images` the file is there.
5. **Public view**: open the home page in a private tab. The product shows with photo, price, offer badge, sizes, colors, stock.
6. **Persistence**: close the browser, reopen. The product is still there.
7. **Edit**: change the price and stock, save, refresh the home page. The change shows. Replace the photo; the old file disappears from Storage.
8. **Search and filters**: search by name; tap the category; tap Special offers.
9. **Instagram order**: open a product, choose size and color, tap Order on Instagram. Instagram opens the @pettaimenswear chat; paste the copied text.
10. **Call**: the Call button opens your phone dialer with +91 63799 70507.
11. **Delete**: delete the test product. It disappears from the shop and its photo is gone from Storage.
12. **Security**: while signed out, `your-link/admin` shows only the login form. A non-admin account sees "No admin access".
13. **Phone check**: repeat 1, 5 and 9 on your iPhone.

## Security notes
- Only the public Supabase URL and anon key are in the website. They are safe only because Row Level Security is on.
- Customers can read products and images. Only accounts listed in `admins` can add, change or delete them. This is enforced by the database, not just the screen.
- Never put the `service_role` key in GitHub or Vercel variables for this site.
