import { useCallback, useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import type { Session } from '@supabase/supabase-js'
import {
  BOTTOM_SIZES,
  CATEGORIES,
  STOCK_LABEL,
  TOP_SIZES,
  deleteProduct,
  fetchProducts,
  inr,
  isConfigured,
  isTopCategory,
  removeImage,
  saveProduct,
  supabase,
  uploadImage,
  type Category,
  type Product,
  type StockStatus,
} from './lib'

/* The browser check below only decides what to SHOW.
   The real protection is Row Level Security in the database (schema.sql). */
function useAdminSession() {
  const [state, setState] = useState({ loading: true, email: null as string | null, isAdmin: false })

  useEffect(() => {
    let active = true
    const check = async (session: Session | null) => {
      if (!session) {
        if (active) setState({ loading: false, email: null, isAdmin: false })
        return
      }
      const { data } = await supabase.from('admins').select('user_id').eq('user_id', session.user.id).maybeSingle()
      if (active) setState({ loading: false, email: session.user.email ?? null, isAdmin: Boolean(data) })
    }
    supabase.auth.getSession().then(({ data }) => check(data.session))
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setTimeout(() => void check(session), 0)
    })
    return () => {
      active = false
      sub.subscription.unsubscribe()
    }
  }, [])
  return state
}

export default function Admin() {
  const auth = useAdminSession()

  useEffect(() => {
    document.title = 'Staff login | PETTAI MEN\'S WEAR'
    const meta = document.createElement('meta')
    meta.name = 'robots'
    meta.content = 'noindex'
    document.head.appendChild(meta)
    return () => meta.remove()
  }, [])

  if (!isConfigured)
    return (
      <Shell>
        <p className="notice">The database is not connected yet. Finish Step 5 of the setup guide.</p>
      </Shell>
    )
  if (auth.loading)
    return (
      <Shell>
        <p className="notice">Checking your login…</p>
      </Shell>
    )
  if (!auth.email) return <Login />
  if (!auth.isAdmin)
    return (
      <Shell>
        <h1>No admin access</h1>
        <p className="notice notice-error">
          {auth.email} is signed in but is not on the admin list. Ask the site owner to add this account (Step 3 of the guide).
        </p>
        <button className="btn btn-line" onClick={() => supabase.auth.signOut()}>
          Sign out
        </button>
      </Shell>
    )
  return <Dashboard email={auth.email} />
}

function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="admin-wrap">
      <div className="admin-box">{children}</div>
      <p className="fine center">
        <Link to="/">Back to the shop</Link>
      </p>
    </div>
  )
}

function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
    if (error) setError('Email or password is not correct.')
    setBusy(false)
  }

  return (
    <Shell>
      <h1>Staff login</h1>
      <form onSubmit={submit} className="form">
        <label>
          Email
          <input type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>
          Password
          <input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        {error && <p className="notice notice-error">{error}</p>}
        <button className="btn btn-gold btn-full" disabled={busy}>
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </Shell>
  )
}

function Dashboard({ email }: { email: string }) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [editing, setEditing] = useState<Product | 'new' | null>(null)

  const load = useCallback(async () => {
    try {
      setProducts(await fetchProducts())
      setError('')
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setLoading(false)
    }
  }, [])
  useEffect(() => {
    void load()
  }, [load])

  const remove = async (p: Product) => {
    if (!window.confirm(`Delete "${p.name}"? This cannot be undone.`)) return
    try {
      await deleteProduct(p)
      await load()
    } catch (e) {
      setError((e as Error).message)
    }
  }

  return (
    <div className="admin-page">
      <div className="admin-top">
        <div>
          <h1>Products</h1>
          <p className="fine">Signed in as {email}</p>
        </div>
        <div className="admin-actions">
          <button className="btn btn-gold" onClick={() => setEditing('new')}>
            Add product
          </button>
          <button className="btn btn-line" onClick={() => supabase.auth.signOut()}>
            Sign out
          </button>
        </div>
      </div>
      <p className="fine">
        <Link to="/">View the shop</Link>
      </p>
      {error && <p className="notice notice-error">{error}</p>}
      {loading ? (
        <p className="notice">Loading…</p>
      ) : products.length === 0 ? (
        <p className="notice">No products yet. Tap “Add product” to create the first one.</p>
      ) : (
        <ul className="admin-list">
          {products.map((p) => (
            <li key={p.id}>
              {p.image_url ? <img src={p.image_url} alt="" /> : <span className="thumb-empty" />}
              <div className="admin-info">
                <strong>{p.name}</strong>
                <span>
                  {p.category} · {inr(p.offer_price ?? p.price)} · {STOCK_LABEL[p.stock_status]}
                </span>
              </div>
              <div className="admin-row-actions">
                <button className="btn btn-line btn-sm" onClick={() => setEditing(p)}>
                  Edit
                </button>
                <button className="btn btn-danger btn-sm" onClick={() => void remove(p)}>
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
      {editing && (
        <ProductForm
          initial={editing === 'new' ? undefined : editing}
          onCancel={() => setEditing(null)}
          onSaved={async () => {
            setEditing(null)
            await load()
          }}
        />
      )}
    </div>
  )
}

function ProductForm({ initial, onCancel, onSaved }: { initial?: Product; onCancel: () => void; onSaved: () => Promise<void> }) {
  const [name, setName] = useState(initial?.name ?? '')
  const [category, setCategory] = useState<Category>(initial?.category ?? 'Shirts')
  const [description, setDescription] = useState(initial?.description ?? '')
  const [price, setPrice] = useState(initial ? String(initial.price) : '')
  const [offer, setOffer] = useState(initial?.offer_price ? String(initial.offer_price) : '')
  const [sizes, setSizes] = useState<string[]>(initial?.sizes ?? [])
  const [colors, setColors] = useState((initial?.colors ?? []).join(', '))
  const [stock, setStock] = useState<StockStatus>(initial?.stock_status ?? 'in_stock')
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState(initial?.image_url ?? '')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const sizeChoices = isTopCategory(category) ? TOP_SIZES : BOTTOM_SIZES

  const changeCategory = (c: Category) => {
    if (isTopCategory(c) !== isTopCategory(category)) setSizes([])
    setCategory(c)
  }
  const toggleSize = (s: string) => setSizes((cur) => (cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s]))
  const pickFile = (f: File | null) => {
    setFile(f)
    if (f) setPreview(URL.createObjectURL(f))
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    const priceN = Number(price)
    const offerN = offer.trim() ? Number(offer) : null
    if (!name.trim()) return setError('Enter the product name.')
    if (!(priceN > 0)) return setError('Enter a price greater than 0.')
    if (offerN !== null && !(offerN > 0 && offerN < priceN)) return setError('The offer price must be lower than the normal price.')
    if (sizes.length === 0) return setError('Choose at least one size.')
    if (!file && !initial?.image_url) return setError('Add a product photo.')

    setBusy(true)
    let uploaded: { url: string; path: string } | null = null
    try {
      if (file) uploaded = await uploadImage(file)
      await saveProduct(
        {
          name: name.trim(),
          category,
          description: description.trim() || null,
          price: priceN,
          offer_price: offerN,
          sizes,
          colors: colors.split(',').map((c) => c.trim()).filter(Boolean),
          stock_status: stock,
          image_url: uploaded?.url ?? initial?.image_url ?? null,
          image_path: uploaded?.path ?? initial?.image_path ?? null,
        },
        initial?.id,
      )
      if (uploaded && initial?.image_path) await removeImage(initial.image_path)
      await onSaved()
    } catch (err) {
      if (uploaded) await removeImage(uploaded.path)
      setError((err as Error).message || 'Something went wrong. Please try again.')
      setBusy(false)
    }
  }

  return (
    <div className="overlay">
      <form className="sheet form" onSubmit={submit}>
        <h2>{initial ? 'Edit product' : 'Add product'}</h2>

        <label>
          Photo
          <input type="file" accept="image/*" onChange={(e) => pickFile(e.target.files?.[0] ?? null)} />
        </label>
        {preview && <img className="form-preview" src={preview} alt="Preview" />}

        <label>
          Name
          <input value={name} onChange={(e) => setName(e.target.value)} maxLength={120} required />
        </label>
        <label>
          Category
          <select value={category} onChange={(e) => changeCategory(e.target.value as Category)}>
            {CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <div className="two">
          <label>
            Price (₹)
            <input inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} required />
          </label>
          <label>
            Offer price (₹)
            <input inputMode="decimal" placeholder="Optional" value={offer} onChange={(e) => setOffer(e.target.value)} />
          </label>
        </div>

        <fieldset>
          <legend>Sizes available</legend>
          <div className="opts">
            {sizeChoices.map((s) => (
              <button type="button" key={s} className={`opt ${sizes.includes(s) ? 'opt-on' : ''}`} onClick={() => toggleSize(s)}>
                {s}
              </button>
            ))}
          </div>
        </fieldset>

        <label>
          Colors (separate with commas)
          <input placeholder="Black, Navy, Olive" value={colors} onChange={(e) => setColors(e.target.value)} />
        </label>
        <label>
          Stock
          <select value={stock} onChange={(e) => setStock(e.target.value as StockStatus)}>
            {(Object.keys(STOCK_LABEL) as StockStatus[]).map((s) => (
              <option key={s} value={s}>
                {STOCK_LABEL[s]}
              </option>
            ))}
          </select>
        </label>
        <label>
          Description (optional)
          <textarea rows={3} maxLength={1000} value={description} onChange={(e) => setDescription(e.target.value)} />
        </label>

        {error && <p className="notice notice-error">{error}</p>}
        <div className="form-actions">
          <button type="button" className="btn btn-line" onClick={onCancel} disabled={busy}>
            Cancel
          </button>
          <button className="btn btn-gold" disabled={busy}>
            {busy ? 'Saving…' : 'Save product'}
          </button>
        </div>
      </form>
    </div>
  )
}
